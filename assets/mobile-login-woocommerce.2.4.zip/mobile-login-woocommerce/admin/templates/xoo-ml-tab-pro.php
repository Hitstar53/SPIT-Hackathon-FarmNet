<div class="xoo-wsc-premium">
	<div class="xoo-wscp-head">
		<span>Premium</span>
		<a href="https://xootix.com/plugins/mobile-login-for-woocommerce">BUY NOW</a>
		<a href="https://demo.xootix.com/mobile-login-for-woocommerce/">DEMO</a>
	</div>

	<ul class="xoo-wscp-features">
		<li>Woocommerce checkout form OTP verification</li>
		<li>Country Code Flags</li>
		<li>Login With Email OTP</li>
		<li>Beautfil Login & Register form design. This is a separate plugin, feel free to download free version <a href="https://wordpress.org/plugins/easy-login-woocommerce/" target="_blank">here</a><br></li>
	</ul>
</div>