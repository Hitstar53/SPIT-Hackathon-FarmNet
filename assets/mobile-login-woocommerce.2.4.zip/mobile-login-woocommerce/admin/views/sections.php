<?php

$sections = array(

	/* General TAB Sections */
	array(
		'title' => 'Main',
		'id' 	=> 'ph_main',
		'tab' 	=> 'phone',
	),

	array(
		'title' => 'OTP',
		'id' 	=> 'ph_otp',
		'tab' 	=> 'phone',
	),

	array(
		'title' => 'Register',
		'id' 	=> 'ph_reg',
		'tab' 	=> 'phone',
	),

	array(
		'title' => 'Login',
		'id' 	=> 'ph_login',
		'tab' 	=> 'phone',
	),


	array(
		'id' 	=> 'woocommerce',
		'title' => 'WooCommerce Checkout Settings',
		'tab' 	=> 'phone',
		'pro' 	=> 'yes'
	),

	array(
		'id' 	=> 'ph_popup',
		'title' => 'Popup Settings',
		'tab' 	=> 'phone',
		'desc' 	=> !function_exists('xoo_el') ? '<b>PRO: </b> Integrate OTP login with our Login/Register popup plugin to gain better control over your design. It comes packed with a ton of features.<br>The popup plugin is <b>FREE</b>, you can download and play with it.' : "<b>**NOTE**</b> You will need the pro version of OTP plugin to integrate it with our login/signup popup plugin. The free version works well with the woocommerce's login/register form"
	),


	array(
		'title' => 'Firebase Settings',
		'id' 	=> 'sv_firebase',
		'tab' 	=> 'services',
		'desc' 	=> '<a href="https://docs.xootix.com/mobile-login-for-woocommerce/google-firebase/" target="_blank">Documentation</a>'
	),


	array(
		'title' => 'Amazon SNS Settings',
		'id' 	=> 'sv_aws',
		'tab' 	=> 'services',
		'desc' 	=> '<a href="https://docs.xootix.com/mobile-login-for-woocommerce/amazon-sns/" target="_blank">Documentation</a>'
	),

	array(
		'title' => 'Twilio Settings',
		'id' 	=> 'sv_twilio',
		'tab' 	=> 'services',
		'desc' 	=> '<a href="https://docs.xootix.com/mobile-login-for-woocommerce/twilio/" target="_blank">Documentation</a>'
	),



);

return apply_filters( 'xoo_ml_admin_settings_sections', $sections );