<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$settings = array(

	array(
		'callback' 		=> 'upload',
		'title' 		=> 'PHP SDK',
		'id' 			=> 'twilio-phpsdk',
		'section_id' 	=> 'sv_twilio',
		'default' 		=> '',
		'desc' 			=> '<a href="https://xootix.com/wp-content/uploads/twilio.zip">Download from here</a>'
	),

	array(
		'type' 			=> 'setting',
		'callback' 		=> 'text',
		'section_id' 	=> 'sv_twilio',
		'id' 			=> 'twilio-account-sid',
		'title' 		=> 'Account SID',
	),


	array(
		'type' 			=> 'setting',
		'callback' 		=> 'text',
		'section_id' 	=> 'sv_twilio',
		'id' 			=> 'twilio-auth-token',
		'title' 		=> 'Auth Token',
	),

	array(
		'type' 			=> 'setting',
		'callback' 		=> 'text',
		'section_id' 	=> 'sv_twilio',
		'id' 			=> 'twilio-sender-number',
		'title' 		=> 'Sender\'s Number',
	),


	array(
		'type' 			=> 'setting',
		'callback' 		=> 'text',
		'section_id' 	=> 'sv_firebase',
		'id' 			=> 'fb-api-key',
		'title' 		=> 'API key',
	),


	array(
		'type' 			=> 'setting',
		'callback' 		=> 'textarea',
		'section_id' 	=> 'sv_firebase',
		'id' 			=> 'fb-config',
		'title' 		=> 'Config',
		'args' 			=> array(
			'rows' 	=> 9,
			'cols' 	=> 60
		)
	),

	array(
		'callback' 		=> 'upload',
		'title' 		=> 'PHP SDK',
		'id' 			=> 'aws-phpsdk',
		'section_id' 	=> 'sv_aws',
		'default' 		=> '',
		'desc' 			=> '<a href="https://xootix.com/wp-content/uploads/sms-services/aws.zip">Download from here</a>'
	),

	array(
		'type' 			=> 'setting',
		'callback' 		=> 'text',
		'section_id' 	=> 'sv_aws',
		'id' 			=> 'asns-access-key',
		'title' 		=> 'Access key',
	),


	array(
		'type' 			=> 'setting',
		'callback' 		=> 'text',
		'section_id' 	=> 'sv_aws',
		'id' 			=> 'asns-secret-key',
		'title' 		=> 'Secret access key',
	),


);

return $settings;

?>
